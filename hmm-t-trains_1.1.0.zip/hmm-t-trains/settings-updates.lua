if mods["hmm-settings"] then
    local util = require("__hmm-settings__/util")
    local settings = require("mod-settings")

    util.updateSettings(settings)
end
