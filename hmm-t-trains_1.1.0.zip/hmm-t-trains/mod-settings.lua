local settings = {}

if mods["Automatic_Train_Painter"] then
    table.insert(settings,{"loc-eqpm-grid", true})
    table.insert(settings,{"loc-eqpm-grid-w", nil})
    table.insert(settings,{"loc-eqpm-grid-h", 2})

    table.insert(settings,{"paint-loco", nil})
    table.insert(settings,{"paint-cargo-wagon", true})
    table.insert(settings,{"paint-fluid-wagon", true})
    table.insert(settings,{"unpaint-empty", nil})
    table.insert(settings,{"u-loco", nil})
    table.insert(settings,{"u-cargo-wagon", nil})
    table.insert(settings,{"u-fluid-wagon", nil})
end

if mods["automatic-station-painter"] then
    table.insert(settings,{"blend-ratio", nil})
end

if mods["Honk"] then
    table.insert(settings,{"honk-speakers", nil})
    table.insert(settings,{"honk-sound-range-boat", 7.5})
    table.insert(settings,{"honk-sound-volume-boat", 0.75})
    table.insert(settings,{"honk-sound-range-diesel", 7.5})
    table.insert(settings,{"honk-sound-volume-diesel", 0.75})
    table.insert(settings,{"honk-sound-range-ship", 7.5})
    table.insert(settings,{"honk-sound-volume-ship", 0.75})
    table.insert(settings,{"honk-sound-range-steam", 7.5})
    table.insert(settings,{"honk-sound-volume-steam", 0.75})


    table.insert(settings,{"honk-default-sound", nil})
    table.insert(settings,{"honk-sound-locos-none", nil})
    table.insert(settings,{"honk-sound-locos-boat", nil})
    table.insert(settings,{"honk-sound-locos-diesel", nil})
    table.insert(settings,{"honk-sound-locos-ship", nil})
    table.insert(settings,{"honk-sound-locos-steam", nil})

    table.insert(settings,{"honk-sound-start-boat", nil})
    table.insert(settings,{"honk-sound-station-boat", nil})
    table.insert(settings,{"honk-sound-signal-boat", nil})
    table.insert(settings,{"honk-sound-lost-boat", nil})
    table.insert(settings,{"honk-sound-manual-boat", nil})
    table.insert(settings,{"honk-sound-manual-alt-boat", nil})

    table.insert(settings,{"honk-sound-start-diesel", nil})
    table.insert(settings,{"honk-sound-station-diesel", nil})
    table.insert(settings,{"honk-sound-signal-diesel", nil})
    table.insert(settings,{"honk-sound-lost-diesel", nil})
    table.insert(settings,{"honk-sound-manual-diesel", nil})
    table.insert(settings,{"honk-sound-manual-alt-diesel", nil})

    table.insert(settings,{"honk-sound-start-ship", nil})
    table.insert(settings,{"honk-sound-station-ship", nil})
    table.insert(settings,{"honk-sound-signal-ship", nil})
    table.insert(settings,{"honk-sound-lost-ship", nil})
    table.insert(settings,{"honk-sound-manual-ship", nil})
    table.insert(settings,{"honk-sound-manual-alt-ship", nil})

    table.insert(settings,{"honk-sound-start-steam", nil})
    table.insert(settings,{"honk-sound-station-steam", nil})
    table.insert(settings,{"honk-sound-signal-steam", nil})
    table.insert(settings,{"honk-sound-lost-steam", nil})
    table.insert(settings,{"honk-sound-manual-steam", nil})
    table.insert(settings,{"honk-sound-manual-alt-steam", nil})
end

if mods["ick-automatic-train-repair"] then
    table.insert(settings,{"ick-automatic-mode", nil})
    table.insert(settings,{"ick-include-equipment", nil})
    table.insert(settings,{"ick-include-fuel", nil})
    table.insert(settings,{"ick-fuel-type", nil})
    table.insert(settings,{"ick-fuel-amount", 3})

    table.insert(settings,{"ick-alert", nil})
end

if mods["LogisticTrainNetwork"] then
    table.insert(settings,{"ltn-dispatcher-enabled", nil})
    table.insert(settings,{"ltn-dispatcher-nth_tick", 10})
    table.insert(settings,{"ltn-dispatcher-updates-per-tick", nil})
    table.insert(settings,{"ltn-interface-console-level", nil})
    table.insert(settings,{"ltn-interface-message-filter-age", 9000})
    table.insert(settings,{"ltn-interface-message-gps", nil})
    table.insert(settings,{"ltn-interface-debug-logfile", nil})
    table.insert(settings,{"ltn-dispatcher-requester-threshold", nil})
    table.insert(settings,{"ltn-dispatcher-provider-threshold", nil})
    table.insert(settings,{"ltn-dispatcher-schedule-circuit-control", nil})
    table.insert(settings,{"ltn-dispatcher-depot-inactivity(s)", nil})
    table.insert(settings,{"ltn-dispatcher-stop-timeout(s)", 0})
    table.insert(settings,{"ltn-dispatcher-delivery-timeout(s)", nil})
    table.insert(settings,{"ltn-dispatcher-requester-delivery-reset", nil})
    table.insert(settings,{"ltn-dispatcher-finish-loading", nil})
    table.insert(settings,{"ltn-depot-reset-filters", nil})
    table.insert(settings,{"ltn-depot-fluid-cleaning", nil})
    table.insert(settings,{"ltn-stop-default-network", 0})
    table.insert(settings,{"ltn-provider-show-existing-cargo", nil})

    table.insert(settings,{"ltn-interface-factorio-alerts", nil})
end

if mods["ltn-cleanup"] then
    table.insert(settings,{"ltn-cleanup-failed-trains", true})
end

if mods["LtnManager"] then
    table.insert(settings,{"ltnm-history-length", nil})
    table.insert(settings,{"ltnm-iterations-per-tick", 1})
end

if mods["LTN_Combinator_Modernized"] then
    table.insert(settings,{"ltnc-upgradable", true})
    table.insert(settings,{"ltnc-signal-rows", nil})

    table.insert(settings,{"ltnc-high-provide-threshold", nil})
    table.insert(settings,{"ltnc-disable-built-combinators", nil})
    table.insert(settings,{"ltnc-emit-default-network-id", true})

    table.insert(settings,{"ltnc-show-all-panels", nil})
    table.insert(settings,{"ltnc-show-net-panel", true})
    table.insert(settings,{"ltnc-slider-max-items", 160})
    table.insert(settings,{"ltnc-use-stacks", nil})
    table.insert(settings,{"ltnc-slider-max-fluid", 200000})
    table.insert(settings,{"ltnc-negative-signals", nil})
end

if mods["LTN_Content_Reader"] then
    table.insert(settings,{"ltn_content_reader_update_interval", 300})
end

if mods["RailSignalPlanner"] then
    -- table.insert(settings,{"rsp-toggle-menu-icon", nil})
end

if mods["se-ltn-glue"] then
    table.insert(settings,{"se-ltn-use-elevator-clearance", true})
    table.insert(settings,{"se-ltn-elevator-clearance-name", nil})
end

return settings